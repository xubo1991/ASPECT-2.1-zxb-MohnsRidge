// Exactly like plugin_dependency.cc

#include "plugin_dependency.cc"
