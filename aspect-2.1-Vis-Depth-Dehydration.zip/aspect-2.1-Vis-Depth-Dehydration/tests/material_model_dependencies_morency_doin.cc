#include "material_model_dependencies.cc"
#include "../cookbooks/morency_doin_2004/morency_doin.h"
#include "../cookbooks/morency_doin_2004/morency_doin.cc"

