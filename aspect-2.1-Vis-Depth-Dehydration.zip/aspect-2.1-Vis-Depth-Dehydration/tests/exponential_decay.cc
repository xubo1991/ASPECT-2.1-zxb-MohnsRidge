#include "../benchmarks/operator_splitting/exponential_decay/exponential_decay.cc"

