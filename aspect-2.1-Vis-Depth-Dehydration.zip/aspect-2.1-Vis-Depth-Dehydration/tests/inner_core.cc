#include "../cookbooks/inner_core_convection/inner_core_assembly.cc"
