#include "../benchmarks/annulus/annulus.cc"
