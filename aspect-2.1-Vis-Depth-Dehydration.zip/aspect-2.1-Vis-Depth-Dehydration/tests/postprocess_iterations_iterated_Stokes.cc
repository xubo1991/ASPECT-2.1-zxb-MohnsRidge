#include "no_adiabatic_heating_03.cc"
