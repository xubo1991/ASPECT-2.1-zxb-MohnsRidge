#include "../benchmarks/hollow_sphere/hollow_sphere.cc"

